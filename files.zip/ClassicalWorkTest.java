package by.bsu.lab4.entity;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ClassicalWorkTest {
    private ClassicalWork work;

    @BeforeMethod
    public void setUp() {
        work = new ClassicalWork("Moonlight Sonata", "Daniel Barenboim", 360,
                MusicStyle.CLASSICAL, "Beethoven", 27);
    }

    @Test
    public void testGetters() {
        Assert.assertEquals(work.getTitle(), "Moonlight Sonata");
        Assert.assertEquals(work.getArtist(), "Daniel Barenboim");
        Assert.assertEquals(work.getDurationSeconds(), 360);
        Assert.assertEquals(work.getStyle(), MusicStyle.CLASSICAL);
        Assert.assertEquals(work.getComposer(), "Beethoven");
        Assert.assertEquals(work.getOpusNumber(), 27);
    }

    @Test
    public void testToString() {
        Assert.assertEquals(work.toString(),
                "ClassicalWork[title=Moonlight Sonata, artist=Daniel Barenboim, duration=360s, "
                        + "style=CLASSICAL, composer=Beethoven, opusNumber=27]");
    }
}
